import React from 'react';

export default class Companies  extends React.Component {

  render(){
    return   <div className="page page--companies">
        <h2>Companies</h2>
      </div>
  }
}
